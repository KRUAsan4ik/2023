# Maki-Sans

![HEADER_IMAGE](assets/head.png)

## How to build

- Download repo, download & install python, FontForge, illustrator.
- Open build.ai, press Ctrl+Alt+E or "Export for screens"
- Pick SVG format and change folder to repo dir
- Open fontforge-console.bat from FontForge root dir
- Change dir to repo and type in console: `ffpython batch_import_svg.py`
- Open output.sfd and generate font.

